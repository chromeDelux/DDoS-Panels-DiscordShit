﻿namespace yikes
{
    public enum DiscordBuild
    {
        Discord,
        DiscordPTB,
        DiscordCanary
    }
}
