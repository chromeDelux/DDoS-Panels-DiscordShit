This is a nuke bot made by https://youtube.com/snipcola, proudly made in Python.

To edit the Prefix, Token and more (if more is added, of course), edit config.json and change the file corresponding to, example, the prefix you want or your bots token.

Dependencies:
- discord.py
- asyncio
- colorama

Commands:
- nuke (changes the name of the server; bans everyone; deletes all channels, roles, everything!)
- destroy (makes multiple channels, roles; spam mass-pings everyone in every single channel; dms everyone in the server; changes server name)
- sdestroy (stops the destroy command)
- dm all (dms everyone in the server whatever you want it to dm)
- ban all (bans everyone)
- kick all (kicks everyone)
- cls (this clears the console)
- help (shows all commands in console)

How to run:
Either double-click Main.py, or run.bat (if you do run.bat instead, if any errors occur, you can actually see the errors.)
