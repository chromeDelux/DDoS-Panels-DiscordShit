-### DiscordHaxx README ###-

### Why can i not see the file? ###
Your antivirus might block the executable, or other libraries used.
Do not be alarmed however, this is only something known as a false positive.
A false positive is the basic concept of when an antivirus blocks something thinking it's malicious, while it's really not.


### Why doesn't it open? ###
If the program doesn't load, make sure your files and folders are ok.
It's also recommended to have vcredist and .net 4.7 installed, since it's what DH uses.


### I don't trust it ###
It's completely up to you if you wanna use it or not.
But i can guarentee you that DiscordHaxx is in no way malicious towards it's users.