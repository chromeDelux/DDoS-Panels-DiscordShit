﻿namespace AnarchyGrabber
{
    public enum DiscordBuild
    {
        Discord,
        DiscordPTB,
        DiscordCanary
    }
}
