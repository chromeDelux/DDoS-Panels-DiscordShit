#pragma once

#define HTTP_SERVER "178.63.167.44"
#define HTTP_PORT 80

#define TFTP_SERVER "178.63.167.44"
